<?php

require_once("usuario.php");


$nombre = $_REQUEST["nombre"];
$apellidos = $_REQUEST["apellidos"];
$edad = $_REQUEST["edad"];


//Me creo mi array de usuarios
$usuarios=[];

//Creo el usuario de los datos del form
$usuario = new Usuario();
$usuario->setNombre($nombre)->setApellidos($apellidos)->setEdad($edad);

//Lo guardo en el array;
$usuarios[]=$usuario;
var_dump($usuarios);

echo "<br>";
/*
$usuario2 = new Usuario("Junior", "Alonso", "20");
echo $usuario2;

echo "<br>";

$usuario3 = Usuario::createRandomUser();
echo $usuario3;*/
